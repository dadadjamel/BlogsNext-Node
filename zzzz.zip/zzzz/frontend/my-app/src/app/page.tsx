import BlogsPage from "./blogs";

export default function Home() {
  return (
    <div>
      This is the home of blog page
      <BlogsPage/>
    </div>
  );
}
